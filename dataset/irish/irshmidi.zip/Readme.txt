Copyright Notice

These midi files are NOT in the public domain! Though the tunes 
(melodies and lyrics) are public domain the arrangements and the 
midi sequences themselves are not.

There is one tune in the collection that is not in the public 
domain... The Flower of Scotland... written by the late Roy 
Williamson of The Corries. Through its phenomenal popularity, 
this tune has been adopted by Scots worldwide as the unofficial 
anthem of Scotland.

Without seeking permission you may...

o Download and enjoy these midi sequences.
o Distribute the collection zip files via bulletin board systems,
  FTP sites and shareware libraries... provided that you include 
  a copy of this ReadMe file.
o Use a midi for embedded background music on your personal or 
  commercial web pages, provided that you include a simple 
  acknowledgement, such as "Midi files sequenced by Barry Taylor."
o Use a midi for background music in Outlook Express stationery. 
  In this instance no acknowledgement is necessary.
o Offer multiple files for download from your WWW site provided 
  that you include a visible acknowledgement such as "Midi files sequenced by Barry Taylor."

You may not...

o Distribute or re-post altered versions of these midi sequences.
o Sell or charge a fee for the use of these midi files.
o Publish these sequences either in electronic (e.g., CD) or hard 
  copy form.
o Transform and repost / redistribute these midi files as karaoke 
  (.kar) files.

Barry Taylor, Victoria, British Columbia, Canada
